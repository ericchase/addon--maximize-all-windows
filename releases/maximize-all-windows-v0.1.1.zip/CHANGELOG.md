## v0.1

Simple browser action with icon.  
Options page to enable/disable maximize on startup.
