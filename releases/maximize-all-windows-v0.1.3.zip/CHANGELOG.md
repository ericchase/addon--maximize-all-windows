## v0.1.3

Added "Maximize on Created" option to "Maximize windows when they are created." Set "Maximize windows when they are created." option to true by default.

## v0.1.2

Changed "Maximize on Browser Startup" option to "Maximize windows on browser startup." Set "Maximize windows on browser startup." option to true by default.

Added "Minimize windows that were minimized before maximizing." option to minimize windows that were minimized before maximizing happened. Also set to true by default.

## v0.1.1

Added uuid to manifest. 

## v0.1

Simple browser action with icon.  
Options page to enable/disable maximize on startup.
