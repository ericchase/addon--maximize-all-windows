## v0.1.2

Set 'Maximize on Browser Startup' option to true by default.
Minimize windows that were minimized before the extension action.

## v0.1.1

Added uuid to manifest. 

## v0.1

Simple browser action with icon.  
Options page to enable/disable maximize on startup.
